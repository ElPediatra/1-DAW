//Alberto Gómez Morales - 1º DAW - Ejercicios Recuperación Junio Primer Trimestre

/*
 * 9.- Escriba una apliación que muestre un cuadro, un ovalo, una flecha y un diamante usando asteríscos (*), como se muestra a continuación:
 * *********   ***     *         *
 * *       *  *   *   ***       * *
 * *       * *     * *****     *   *
 * *       * *     *   *      *     *
 * *       * *     *   *     *       *
 * *       * *     *   *      *     *
 * *       * *     *   *       *   *
 * *       *  *   *    *        * *
 * *********   ***     *         *
 */

public class T2_R1_Ej9_GomezMorales_Alberto {
    public static void main(String[] args){
        System.out.printf("*********   ***     *         *%n*       *  *   *   ***       * *%n*       * *     * *****     *   *%n*       * *     *   *      *     *%n*       * *     *   *     *       *%n*       * *     *   *      *     *%n*       * *     *   *       *   *%n*       *  *   *    *        * *%n*********   ***     *         *");
    }
}
