//Alberto Gómez Morales - 1º DAW - Ejercicios Recuperación Junio Primer Trimestre

/*
 * 10.- ¿Qué imprime el siguiente código?
 *      System.out.printf(“*%n**%n***%n****%n*****%n”);
 */

public class T2_R1_Ej10_GomezMorales_Alberto {
    public static void main(String[] args){
        //Imprime la imagen:
        // *
        // **
        // ***
        // ****
        // *****
        System.out.printf("*%n**%n***%n****%n*****%n");
    }
}
