//Alberto Gómez Morales - 1º DAW - Ejercicios Recuperación Junio Primer Trimestre

/*
 * 11.- ¿Qué imprime el siguiente código?
 *      System.out.println("*");
 *      System.out.println("***");
 *      System.out.println("*****");
 *      System.out.println("****");
 *      System.out.println("**");
 */

public class T2_R1_Ej11_GomezMorales_Alberto {
    public static void main(String[] args){

        //Imprime esta imagen:
        //*
        //***
        //*****
        //****
        //**
        System.out.println("*");
        System.out.println("***");
        System.out.println("*****");
        System.out.println("****");
        System.out.println("**");
    }
}
