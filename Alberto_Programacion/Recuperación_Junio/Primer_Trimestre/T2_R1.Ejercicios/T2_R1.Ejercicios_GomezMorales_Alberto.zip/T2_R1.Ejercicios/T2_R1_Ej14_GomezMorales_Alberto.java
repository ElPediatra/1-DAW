//Alberto Gómez Morales - 1º DAW - Ejercicios Recuperación Junio Primer Trimestre

/*
 * 14.- ¿Qué imprime el siguiente código?
 *      System.out.printf("%s%n%s%n%s%n","*","***","*****");
 */

public class T2_R1_Ej14_GomezMorales_Alberto {
    public static void main(String[] args){
        //Imprime:
        //*
        //***
        //*****
        System.out.printf("%s%n%s%n%s%n","*","***","*****");
    }
}
