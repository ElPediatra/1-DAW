/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Poligonos;

/**
 * Alberto Gómez Morales - 1º DAW - Programación
 * Página 275
 * Ejercicio 8.23
 * 
 * @author alber
 * 
 * Implementa la clase abstracta Poligono, con los atributos base y altura, de tipo double
 * y el método abstracto double area().
 */
public class Principal {
    //Sin gestiones, solo hay que crear la clase abstracta
}
