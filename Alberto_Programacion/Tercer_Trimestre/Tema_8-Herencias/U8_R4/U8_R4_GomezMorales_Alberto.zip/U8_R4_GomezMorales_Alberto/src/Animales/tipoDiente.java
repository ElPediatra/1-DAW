/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author alber
 */

/* Paquetes */
package Animales;

public enum tipoDiente { //4 Caninos - 12 Incisivos - 16 Premolares - 10 Molares
    Incisivo,Canino,Premolar,Molar
}
