/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author alber
 */

/* Paquetes */
package Animales;

/* Imports */
import java.util.Scanner;
import java.util.ArrayList;

public class Perros extends Mamiferos {
    private String razaPerros;
    private String nombre;
    private static ArrayList<Perros> perros = new ArrayList<Perros>();
    
    /* Constructores */
    public Perros(){
        super(Sexo.Macho);
        this.razaPerros = "Labrador";
        this.nombre = "Firulais";
    }
    
    public Perros(Sexo sexo, String tipo, String tipoRaza, String nombre){
        super(sexo, tipo);
        this.razaPerros = tipoRaza;
        this.nombre = nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public static ArrayList<Perros> getPerros() {
        return perros;
    }
    
    public String getNombre() {
        return nombre;
    }

    /* Métodos */
    @Override
    public String toString(){ //Super añade texto de este String al de la superclase de esta clase
        return super.toString() + "Raza: "+ this.razaPerros+ "\nNombre: "+ this.nombre + "\n********\n";
    }
    
    public void aullar(){
        System.out.println("Auuuuuuuuuuu...");
    }
    
    public void ladrar(){
        System.out.println("Wooof wooof");
    }
    
    public void comidaPerros(String comida){
        comida = comida.toLowerCase();
        
        if(comida!="sobras"){
            System.out.println("No quiero pienso, dame lo que te ha sobrado");
        } else {
            System.out.println("Que ricas las sobras, jefe");
        }
    }
    
    public void juegaCon(Perros oponente) {
        if (this.getSexo() == Sexo.Macho && oponente.getSexo() == Sexo.Macho) {
            System.out.println("Los perros están jugando!");
        } else {
            System.out.println("No juegan, estos perros optan por dormir.");
        }
    }
    
    /* Método para crear perros */
    public static void crearPerros() {
        /* Variables */
        Sexo sexo;
        String tipo = "de tierra";
        String raza;
        String nombre;
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Indica el nombre del perro: ");
        nombre = teclado.nextLine();
        System.out.println("Indica la raza del perro: ");
        raza = teclado.nextLine();
        System.out.println("Indica el sexo del perro (1) Macho (2) Hembra (3) Hermafrodita:");
        sexo = Sexo.values()[teclado.nextInt()];
        
        // Asignar valor al atributo sexo

        
        perros.add(new Perros(sexo, tipo, raza, nombre));
        System.out.println("Perro añadido con éxito.");
    }

    /* Método para mostrar todos los perros */
    public static void mostrarPerros() {
        if (perros.isEmpty()) {
            System.out.println("No hay perros en la perrera!.");
        } else {
            System.out.println("Lista de perros:");
            for (Perros p : perros) {
                System.out.println(p.toString());
            }
        }
    }
    
    /* Método para consultar un perro en una posición determinada */
    public static void consultarPerro(int posicion) {
        if (posicion >= 0 && posicion < perros.size()) {
            Perros perro = perros.get(posicion);
            System.out.println("Información del perro en la posición " + posicion + ":");
            System.out.println(perro.toString());
        } else {
            System.out.println("No existe ningún perro en la posición especificada.");
        }
    }
    
    public static void modificarNombrePerro(int posicion, String nuevoNombre) {
        if (posicion >= 0 && posicion < perros.size()) {
            Perros perro = perros.get(posicion);
            perro.setNombre(nuevoNombre);
            System.out.println("Nombre del perro modificado correctamente.");
        } else {
            System.out.println("La posición especificada no es válida.");
        }
    }

    public static void eliminarPerro(int posicion) {
        if (posicion >= 0 && posicion < perros.size()) {
            perros.remove(posicion);
            System.out.println("Perro eliminado correctamente.");
        } else {
            System.out.println("La posición especificada no es válida.");
        }
    }

    public static void jugarConTodos() {
        for (Perros perro : perros) {
            System.out.println("Jugando con " + perro.getNombre());
        }
    }
}