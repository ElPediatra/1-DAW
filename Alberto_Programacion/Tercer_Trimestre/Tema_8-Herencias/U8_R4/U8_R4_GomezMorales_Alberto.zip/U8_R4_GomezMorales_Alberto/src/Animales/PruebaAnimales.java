/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author alber
 */

/* Paquetes */
package Animales;

/* Imports */
import java.util.Scanner;

public class PruebaAnimales {
    
    /* Colores String */
    static final String ROJO = "\033[31m"; //Texto color rojo
    static final String VERDE = "\033[32m"; //Texto color verde
    static final String RESET = "\033[0m";  //Texto color por defecto
    
    public static void main(String[] args) {
        menu();
    }

    /* Métodos */
    private static void menu() {
        /* Variables */
        byte opcion;
        char confirmacion;
        boolean salir = false;
        Scanner teclado = new Scanner(System.in);
        Perros perro = new Perros();

        //Desarrollamos el programa
        do {
            menuTexto();
            opcion = teclado.nextByte();
            switch (opcion) {
                case 1:
                    Perros.crearPerros();
                    break;
                
                case 2:
                    Perros.mostrarPerros();
                    break;
                
                case 3:
                    System.out.println("Indica la posición del perro a consultar: ");
                    int posicion = teclado.nextInt();
                    Perros.consultarPerro(posicion);
                    break;
                    
                case 4:
                    System.out.println("Indica la posición del primer perro: ");
                    int posicion1 = teclado.nextInt();
                    System.out.println("Indica la posición del segundo perro: ");
                    int posicion2 = teclado.nextInt();
                    if (posicion1 >= 0 && posicion1 < Perros.getPerros().size() &&
                            posicion2 >= 0 && posicion2 < Perros.getPerros().size()) {
                        Perros perro1 = Perros.getPerros().get(posicion1);
                        Perros perro2 = Perros.getPerros().get(posicion2);
                        perro1.juegaCon(perro2);
                    } else {
                        System.out.println("Posiciones de perros no válidas.");
                    }
                    break;

                case 5:
                    Perros.jugarConTodos();
                    break;
                
                case 6:
                    System.out.println("Indica la posición del perro a eliminar: ");
                    int posicionEliminar = teclado.nextInt();
                    Perros.eliminarPerro(posicionEliminar);
                    break;
                
                case 7:
                    System.out.println("Indica la posición del perro a modificar: ");
                    int posicionModificar = teclado.nextInt();
                    teclado.nextLine(); // Limpiar el búfer
                    System.out.println("Indica el nuevo nombre del perro: ");
                    String nuevoNombre = teclado.nextLine();
                    Perros.modificarNombrePerro(posicionModificar, nuevoNombre);
                    break;
                
                case 0:
                    System.out.println("Has elegido salir, ¿estás seguro?(s/n)");
                    confirmacion = teclado.next().charAt(0);
                    
                    if (confirmacion == 's' || confirmacion == 'S') {
                        System.out.println("\t\t Confirmada su salida del programa. ¡Hasta la próxima!");
                        salir = true;
                        break;
                    }
                    break;
                
                default:
                    System.out.println("Opción no válida. Por favor, selecciona otra opción.");
            }
        } while (!salir);
    }

    /* Texto Menu */
    public static void menuTexto() {
        System.out.println("\t\t Menú de la Perrera ");
        System.out.println(ROJO + "1. " + RESET + "Añadir un perro.");
        System.out.println(ROJO + "2. " + RESET + "Mostrar todos los perros.");
        System.out.println(ROJO + "3. " + RESET + "Consultar un perro.");
        System.out.println(ROJO + "4. " + RESET + "2 perros juegan.");
        System.out.println(ROJO + "5. " + RESET + "Todos los perros juegan.");
        System.out.println(ROJO + "6. " + RESET + "Adoptar un Perro (quitar un perro).");
        System.out.println(ROJO + "7. " + RESET + "Modificar un perro.");
        System.out.println(ROJO + "0. " + RESET + "Salir.");
        System.out.println("\t\tSeleccione una opción por favor.");
    }
}
