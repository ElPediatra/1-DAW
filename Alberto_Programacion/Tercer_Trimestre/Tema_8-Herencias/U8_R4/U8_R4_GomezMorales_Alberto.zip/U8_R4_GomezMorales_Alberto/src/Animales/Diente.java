/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author alber
 */

/* Paquetes */
package Animales;

public class Diente {
    /* Atributos */
    tipoDiente tipo; //Llama a la clase tipoDiente
    String estado;
    
    /* Constructor */
    Diente(tipoDiente tipo){ //Por defecto
        this.tipo = tipo;
        this.estado = "Bueno";
    }
    
    Diente(tipoDiente tipo, String estado){ //Me incluyen los 2 datos
        this.tipo = tipo;
        this.estado = estado;
    }
    
    /* Métodos */
    public boolean estaSano(){
        if(this.estado == "Bueno"){
            return true;
        }
        return false;
    }
}
