package bancoalberto;

import java.util.Calendar;
import java.util.Vector;

public class Persona {

  private String nombre;

  private Calendar fechaNacimiento;

    public Vector  Es;

}