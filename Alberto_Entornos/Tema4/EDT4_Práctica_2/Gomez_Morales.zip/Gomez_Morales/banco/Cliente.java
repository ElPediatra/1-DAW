package bancoalberto;

import java.util.Calendar;
import java.util.Vector;

public class Cliente extends Persona {

  private Calendar fechaAlta;

    /**
   * 
   * @element-type Cartilla
   */
  private Vector  cartilla;

}