package bancoalberto;

import java.util.Vector;

public class Cartilla{

  private double saldo;

    /**
   * 
   * @element-type Cliente
   */
  private Vector  titular;

  public double ingreso() {
  return 0.0;
  }

  public double reintegro() {
  return 0.0;
  }

  public boolean comprobarReintegro() {
  return false;
  }

}