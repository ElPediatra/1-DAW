package bancoalberto;

public class Libreta extends Cartilla {

  private int plazo;

  private Enum tipoInteres;

  public double mostrarBeneficio() {
  return 0.0;
  }

}