package bancoalberto;

import java.util.Vector;

public class Empleado extends Persona {

  private String numSSocial;

    public Vector  Es;
    private Empleado empleado;
    /**
   * 
   * @element-type Empleado
   */

}