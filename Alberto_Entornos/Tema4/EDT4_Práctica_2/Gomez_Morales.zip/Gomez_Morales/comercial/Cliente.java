package centroComercialAlberto;

import java.util.Calendar;

public class Cliente extends Persona {

  private int codCliente;

    /**
   * 
   * @element-type Empresa
   */

  public void asignar(int codCliente, String nombre, Calendar fechaNacimiento, String telefono) {
  }

  public Cliente obtener() {
  return null;
  }

}