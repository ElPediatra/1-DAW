package centroComercialAlberto;

import java.util.Vector;
import java.util.ArrayList;

public class Empresa {

  private String cif;

  private String razonSocial;

  private String direccion;

  private String telefono;

    /**
   * 
   * @element-type Cliente
   */
  public Vector  cliente;
    public Vector  myEmpleado;
    /**
   * 
   * @element-type Empleado
   */
  public Vector  empleado;
    /**
   * 
   * @element-type Empleado
   */

  public void asignar(String cif, String razonSocial, String direccion, String telefono, ArrayList Clientes) {
  }

  public void obtener() {
  }

}