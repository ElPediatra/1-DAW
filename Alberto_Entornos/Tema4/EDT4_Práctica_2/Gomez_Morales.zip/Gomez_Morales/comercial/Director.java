package centroComercialAlberto;

import java.util.Calendar;
import java.util.Vector;

public class Director extends Empleado {

  private String categoria;

  private Calendar fechaAltaDirector;

    /**
   * 
   * @element-type Empleado
   */
  public Vector  empleado;

  public void asignar(String categoria, Calendar fechaAltaDirector, int codEmpleado, Calendar fechaAlta, Double salario, Double comision, String nombre, Calendar fechaNacimiento, String telefono) {
  }

  public Director obtener() {
  return null;
  }

}