package centroComercialAlberto;

import java.util.Calendar;

public class Persona {

  private String nombre;

  private Calendar fechaNacimiento;

  private String telefono;

  public void asignar(String nombre, Calendar fechaNacimiento, String telefono) {
  }

  public Persona obtener() {
  return null;
  }

}