package centroComercialAlberto;

import centroComercialAlberto.Director;
import java.util.Calendar;
import java.util.Vector;

public class Empleado extends Persona {

  private int codEmpleado;

  private Calendar fechaAlta;

  private Double salario;

  private Double comision;

    public Vector  myEmpresa;
        public Empresa empresa;

  public void asignar(int codEmpleado, Calendar fechaAlta, Double salario, Double comision, String nombre, Calendar fechaNacimiento, String telefono, Director director, Empresa empresa) {
  }

  public Empleado obtener() {
  return null;
  }

}